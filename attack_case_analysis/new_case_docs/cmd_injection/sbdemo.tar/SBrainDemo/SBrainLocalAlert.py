#!/usr/bin/env python3
import os
import logging
import logging.handlers
import json
import urllib.parse
import requests
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from multiprocessing import Process, Queue, Value
import random

_DEFAULT_LOG_FORMAT = '%(asctime)s :: line - %(lineno)d :: %(levelname)s - %(message)s'
_LOGGER = logging.getLogger(__name__)
_LOGPATH="/opt/NECLA/SBrainDemo/logs/sbrain.log"

KODI_POST = '''
{"jsonrpc":"2.0","method":"GUI.ShowNotification","params":{"title":"{}","message":"add your message here how I realge from sticky note.add your message here how I realge from sticky noteadd your message here how I realge from sticky noteadd your message here how I realge from sticky note", "displaytime":5000,"image":"/home/pi/alert-image.png"},"id":2}
'''

KODI_POST='''
{
    "id": 2,
    "jsonrpc": "2.0",
    "method": "GUI.ShowNotification",
    "params": {
        "displaytime": %d,
        "image": "/home/pi/alert-image.png",
        "title": "%s",
        "message": "%s"
    }
}
'''

IVIIPLst = ["127.0.0.1", "192.168.4.1", "172.16.157.1", "192.168.5.1" ]

def _configure_logging():
    _LOGGER.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    fch = logging.handlers.WatchedFileHandler(_LOGPATH)
    formatter = logging.Formatter(_DEFAULT_LOG_FORMAT)
    ch.setFormatter(formatter)
    fch.setFormatter(formatter)
    _LOGGER.addHandler(ch)
    _LOGGER.addHandler(fch)


def kodiNotifier(v,q):
    _LOGGER.info("kodiNotifier starts")

    while v.value:
        title, requester, msg = q.get()
        kodi_post = KODI_POST % (5000, title + " from " + requester, msg)
        os.system('DISPLAY=:0.0 /usr/bin/notify-send --urgency=CRITICAL -t 0 "%s" "%s"' % (title + " from " + requester, msg + " " + " " + " " + "http://www.splitbrain.com" ,))
        try:
            for i in range(3):
                r = requests.post("http://kodi:kodi@localhost:8080/jsonrpc",data=kodi_post)
                _LOGGER.info("Kodi post response: " + str(r))
                time.sleep(10)
                os.system("killall kodi_v7.bin")
            else:
                kodi_post = KODI_POST % (20 * 1000, title + " from " + requester, msg)
                r = requests.post("http://kodi:kodi@localhost:8080/jsonrpc",data=kodi_post)
                _LOGGER.info("Kodi post response: " + str(r))
                time.sleep(60)
                # os.system("killall kodi_v7.bin")
        except requests.exceptions.ConnectionError as ce:
            _LOGGER.error("ConnectionError:" + str(ce))

    _LOGGER.info("kodiNotifier finishes")


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'Hello, world!')

    def do_POST(self):
        alertId = -1
        try:
            # Doesn't do anything with posted data
            content_len = int(self.headers.get_all('Content-Length')[0])
            requester = 'IVI' if self.client_address[0] in IVIIPLst else 'TCU'
            post_body = self.rfile.read(content_len)
            post_json = json.loads(post_body.decode('utf-8'))
            _LOGGER.info("Alert post message: " + str(post_json) + " from " + requester + " IP:" + self.client_address[0])
            title = "CRITICAL security alert"
            alertId = random.randint(0,10000)
            msg = "Please contact your security operators. (AlertID: %d)" % alertId
            Q.put((title, requester, msg))
        except Exception as e:
            _LOGGER.error(e)

        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'{"Status":"OK", "AlertID":%d}' % alertId)


if __name__ == "__main__":
    _configure_logging()
    _LOGGER.info("Starting service")
    V = Value("i", 0)
    Q = Queue()
    V.value = 1  # True
    p = Process(target=kodiNotifier, args=(V,Q,))
    p.start()

    httpd = HTTPServer(('0.0.0.0', 9000), SimpleHTTPRequestHandler)
    try:
        httpd.serve_forever()
    except:
        pass
        
    _LOGGER.info("Finishing service")
    V.value = 0  # False
    p.join()
    _LOGGER.info("Process joined. Exiting")
