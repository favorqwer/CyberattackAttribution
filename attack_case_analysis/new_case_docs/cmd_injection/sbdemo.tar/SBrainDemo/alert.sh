#!/bin/sh
/usr/bin/aplay /opt/NECLA/SBrainDemo/res/beep.wav
