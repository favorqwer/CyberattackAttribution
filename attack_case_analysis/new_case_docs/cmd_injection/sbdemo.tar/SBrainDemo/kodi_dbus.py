#!/usr/bin/env python3

import dbus
import dbus.service
import time
import os
import subprocess

class SBrainKido(dbus.service.Object):
    def __init__(self):
        self.bus = dbus.SessionBus()
        name = dbus.service.BusName('com.necla.SplitBrain', bus=self.bus)
        super().__init__(name, '/Kodi')

    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def CurrentTime(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""

        formatter = '%d-%m-%Y %H:%M:%S'
        return time.strftime(formatter)

    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressSelect(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd= 'kodi-cli -S'
        subprocess.Popen(cmd, shell=True)
        return cmd


    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressVolUp(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -u'
        subprocess.Popen(cmd, shell=True)
        return cmd


    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressVolDown(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -d'
        subprocess.Popen(cmd, shell=True)
        return cmd


    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressUp(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -U'
        subprocess.Popen(cmd, shell=True)
        return cmd

    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressDown(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -D'
        subprocess.Popen(cmd, shell=True)
        return cmd


    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressLeft(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -L'
        subprocess.Popen(cmd, shell=True)
        return cmd


    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressRight(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -R'
        subprocess.Popen(cmd, shell=True)
        return cmd


    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressFull(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -f'
        subprocess.Popen(cmd, shell=True)
        return cmd

    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressPausePlay(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -p'
        subprocess.Popen(cmd, shell=True)
        return cmd

    @dbus.service.method('com.necla.SplitBrain', out_signature='s')
    def PressHome(self):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -E'
        subprocess.Popen(cmd, shell=True)
        return cmd


    @dbus.service.method('com.necla.SplitBrain', in_signature='s', out_signature='s')
    def PlayYouTube(self, addr):
        """Use strftime to return a formatted timestamp
        that looks like 23-02-2018 06:57:04."""
        cmd = 'kodi-cli -y ' + addr
        subprocess.Popen(cmd, shell=True)
        return cmd


if __name__ == '__main__':
    import dbus.mainloop.glib
    from gi.repository import GLib

    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)

    loop = GLib.MainLoop()
    object = SBrainKido()
    loop.run()
