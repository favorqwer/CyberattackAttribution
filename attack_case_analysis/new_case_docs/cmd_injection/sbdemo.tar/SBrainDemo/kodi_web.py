#!/usr/bin/env python
"""
Very simple HTTP server in python.

Usage::
    ./dummy-web-server.py [<port>]

Send a GET request::
    curl http://localhost

Send a HEAD request::
    curl -I http://localhost

Send a POST request::
    curl -d "foo=bar&bin=baz" http://localhost

"""
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
from urlparse import urlparse, parse_qs
import dbus
import time
import urllib

bus = dbus.SessionBus()
def init_dbus_service():
    while True:
        try:
            service = bus.get_object('com.necla.SplitBrain', '/Kodi')
            return service
        except:
            print "Dbus not ready. retrying..."
            time.sleep(1)

html_doc = """
<!DOCTYPE html>
<html>
<head>
<style>
.button-grn {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button-blu {
    background-color: #1a75ff;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button-red {
    background-color: #cc0000;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

</style>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-container w3-blue">
  <h2><a href="">Media Control</a></h2>
</div>

<label>Volumes</label>
<form method="GET" action="volume">
    <input type="submit" class="button-blu" name="command" value="VolumeUp" />
    <input type="submit" class="button-blu" name="command" value="VolumeDown" />
</form>

<br>

<label>Navigation</label>
<form method="GET" action="navigation">
    <input type="submit" class="button-grn" name="command" value="Up" />
    <input type="submit" class="button-grn" name="command" value="Down" />
    <br>
    <input type="submit" class="button-grn" name="command" value="Left" />
    <input type="submit" class="button-grn" name="command" value="Right" />
    <br>
    <input type="submit" class="button-grn" name="command" value="Select" />
</form>

<br>

<label>Pause / Play /Full / Home</label>
<form method="GET" action="control">
    <input type="submit" class="button-blu" name="command" value="PausePlay" />
    <input type="submit" class="button-blu" name="command" value="Full" />
    <input type="submit" class="button-blu" name="command" value="Home" />
</form>

<br>

<form method="POST" action="youtube">
    <label>Youtube Address</label>
    <input type="text" class="w3-input" name="YouTubeAddr" />
    <input type="submit" class="button-red" name="YouTube" value="play" />
</form>

</body>
</html>
"""

def my_urlparse(qs):
    ret = {}
    for token in qs.split("&"):
        kv = token.split("=")

        if len(kv) == 2:
            k, v = kv
            v = urllib.unquote(v).decode('utf8')
        elif len(kv) == 1:
            k, v = kv, ""
        else:
            # TODO: error handling needed.
            print ("Invalid token: %s".format(str(kv)))
            continue
        print "DBG1", k,v
        ret[k] = v.replace("+", " ")
    return ret

class S(BaseHTTPRequestHandler):
    service = None
    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def do_GET(self):
        self._set_headers()
        res = urlparse(self.path)
        cmd = ""

        try:
            if res.path == '/volume':
                qsMap = parse_qs(res.query)
                val = qsMap['command'][0]

                if val == 'VolumeDown':
                   cmd = 'PressVolDown'
                elif val == 'VolumeUp':
                    cmd = 'PressVolUp'
                else:
                    # TODO: warning message.
                    pass

            elif res.path == '/navigation':
                qsMap = parse_qs(res.query)
                val = qsMap['command'][0]

                if val == 'Down':
                    cmd = 'PressDown'
                elif val == 'Up':
                    cmd = 'PressUp'
                elif val == 'Left':
                    cmd = 'PressLeft'
                elif val == 'Right':
                    cmd = 'PressRight'
                elif val == 'Select':
                    cmd = 'PressSelect'
                else:
                    # TODO: warning message.
                    pass

            elif res.path == '/control':
                qsMap = parse_qs(res.query)
                val = qsMap['command'][0]

                if val == 'PausePlay':
                    cmd = 'PressPausePlay'
                elif val == 'Full':
                    cmd = 'PressFull'
                elif val == 'Home':
                    cmd = 'PressHome'
                else:
                    # TODO: warning message.
                    pass

            else:
                # TODO: warning message.
                print "error", res.path
        except Exception as e:
            print "xxx", e

        print "DBG", cmd
        if cmd:
            method = getattr(S.service, cmd)
            method()
        self.wfile.write(html_doc)

    def do_HEAD(self):
        self._set_headers()

    def do_POST(self):
        try:
            # Doesn't do anything with posted data
            content_len = int(self.headers.getheader('content-length', 0))

            post_body = self.rfile.read(content_len)
            print post_body
            qsMap = my_urlparse(post_body)

            """
            post_body = post_body.replace("+", " ")
            post_body = urllib.unquote(post_body).decode('utf8')
            qsMap = parse_qs(post_body)
            """
            print "DBG", qsMap
            S.service.PlayYouTube(qsMap["YouTubeAddr"])

        except Exception as e:
            print "yyy", e

        self._set_headers()
        self.wfile.write(html_doc)


def run(server_class=HTTPServer, handler_class=S, port=8000):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print('Starting httpd...')
    httpd.serve_forever()


if __name__ == "__main__":
    from sys import argv
    S.service = init_dbus_service()
    print("Current time:" + S.service.CurrentTime())

    if len(argv) == 2:
        run(port=int(argv[1]))
    else:
        run()

